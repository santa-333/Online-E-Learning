<form action="upload.php" method="post" enctype="multipart/form-data">
  <label for="video">Select a video:</label>
  <input type="file" name="video" id="video">
  <label for="title">Title:</label>
  <input type="text" name="title" id="title">
  <label for="description">Description:</label>
  <textarea name="description" id="description"></textarea>
  <input type="submit" name="submit" value="Upload">
</form>


